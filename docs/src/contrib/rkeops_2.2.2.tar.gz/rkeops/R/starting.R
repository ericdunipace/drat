#' @title helloWorld
#' @keywords internal
#' @name helloWorld
#' @description dummy function to init package
#' @return None
#' @export
helloWorld <- function() {
    print("Hello user of KeOps")
}
